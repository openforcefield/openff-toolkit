"""

Regenerate the OpenMM XML files with openforcefield 0.0.2 to enable tests
for the problematic molecules described in

    https://github.com/openforcefield/openforcefield/issues/175#issuecomment-464350885.

The original code was taken from

    https://github.com/MobleyLab/SMIRNOFF_paper_code/blob/master/FreeSolv/scripts/create_input_files.py#L70

I've installed the necessary packages on Feb 15th, 2019 with:

    conda install openforcefield=0.0.2 python=3.5
    conda install networkx=1.11
    conda install -c openeye openeye-toolkits=2018.10.1

then I had to go in the installed code and comment this line

    https://github.com/openforcefield/openforcefield/blob/0.0.2/openforcefield/typing/engines/smirnoff/forcefield.py#L110

to regenerate XML files not affected by the bug.

"""


import os
from simtk import openmm
from openeye import oechem
from openforcefield.typing.engines import smirnoff


def load_oe_graph_mol(mol2_filepath):
    """Load a single OpenEye molecule from a mol2 file."""
    # OpenEye flavors to use when loading mol2 files.
    flavor = oechem.OEIFlavor_Generic_Default | oechem.OEIFlavor_MOL2_Default | oechem.OEIFlavor_MOL2_Forcefield

    ifs = oechem.oemolistream(mol2_filepath)
    ifs.SetFlavor(oechem.OEFormat_MOL2, flavor)

    mol = oechem.OEGraphMol()

    molecules = []
    while oechem.OEReadMolecule(ifs, mol):
        oechem.OETriposAtomNames(mol)
        oemol = oechem.OEGraphMol(mol)

        molecules.append(oemol)

    # The script assumes we have only 1 molecule per mol2 file.
    assert len(molecules) == 1
    return molecules[0]


def regenerate_xml(freesolv_id):
    regenerated_dir = 'regenerated'

    filename = 'mobley_' + freesolv_id
    molecule_mol2_filepath = 'mol2files_sybyl/' + filename + '.mol2'
    vacuum_pdb_filepath = 'pdbfiles/' + filename + '_vacuum.pdb'
    vacuum_xml_filepath = regenerated_dir + '/' + filename + '_vacuum.xml'

    # Load solvated molecule into OpeneEye molecule.
    molecule_oe_mol = load_oe_graph_mol(molecule_mol2_filepath)

    # Load forcefield.
    hbonds_ff_path = os.path.join(os.path.realpath(__file__), '..', '..', 'forcefield', 'old', 'hbonds.offxml')
    ff = smirnoff.ForceField('forcefield/smirnoff99Frosst.ffxml', hbonds_ff_path)

    # Load vacuum and solvated PDBFiles.
    pdb_file_vacuum = openmm.app.PDBFile(vacuum_pdb_filepath)

    # Create vacuum and solvated system.
    system_vacuum = ff.createSystem(pdb_file_vacuum.topology, molecules=[molecule_oe_mol],
                                    nonbondedMethod=smirnoff.NoCutoff)

    # Save XML files.
    os.makedirs(regenerated_dir, exist_ok=True)
    for system, xml_filepath in [(system_vacuum, vacuum_xml_filepath)]:  #, (system_solvated, solvated_xml_filepath)]:
        system_serialized = openmm.XmlSerializer.serialize(system)
        with open(xml_filepath, 'w') as f:
            f.write(system_serialized)


if __name__ == '__main__':
    freesolv_ids = [
        '3323117',  # Bond fail

        '63712',  # Torsion fail
        '1944394',
        '2771569',
        '4059279',
        '5282042',
        '8449031',
        '8558116',
        '9209581',
    ]
    for freesolv_id in freesolv_ids:
        regenerate_xml(freesolv_id)
